from django.contrib import admin

from .models import (
    InventoryCount,
    InventoryCountItem,
    Notification,
    Receipt,
    ReceiptItem,
    Shipment,
    ShipmentItem,
    StockBalance,
    StockMovement,
)


class ReceiptItemInline(admin.TabularInline):
    model = ReceiptItem
    extra = 1


@admin.register(Receipt)
class ReceiptAdmin(admin.ModelAdmin):
    list_display = ("number", "supplier", "received_at", "status", "created_by")
    list_filter = ("status", "supplier")
    search_fields = ("number", "supplier__name")
    inlines = (ReceiptItemInline,)


class ShipmentItemInline(admin.TabularInline):
    model = ShipmentItem
    extra = 1


@admin.register(Shipment)
class ShipmentAdmin(admin.ModelAdmin):
    list_display = ("number", "destination", "planned_at", "shipped_at", "status")
    list_filter = ("status",)
    search_fields = ("number", "destination")
    inlines = (ShipmentItemInline,)


class InventoryCountItemInline(admin.TabularInline):
    model = InventoryCountItem
    extra = 1
    readonly_fields = ("difference_value",)

    @admin.display(description="Отклонение")
    def difference_value(self, obj):
        return obj.difference if obj.pk else "—"


@admin.register(InventoryCount)
class InventoryCountAdmin(admin.ModelAdmin):
    list_display = ("number", "started_at", "completed_at", "status", "responsible")
    list_filter = ("status",)
    search_fields = ("number",)
    inlines = (InventoryCountItemInline,)


@admin.register(StockBalance)
class StockBalanceAdmin(admin.ModelAdmin):
    list_display = ("product", "location", "quantity", "updated_at")
    list_filter = ("location",)
    search_fields = ("product__sku", "product__name", "location__code")


@admin.register(StockMovement)
class StockMovementAdmin(admin.ModelAdmin):
    list_display = ("product", "source", "destination", "quantity", "moved_at", "moved_by")
    list_filter = ("source", "destination")
    search_fields = ("product__sku", "product__name")


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ("title", "user", "is_read", "created_at")
    list_filter = ("is_read",)
    search_fields = ("title", "message", "user__username")
