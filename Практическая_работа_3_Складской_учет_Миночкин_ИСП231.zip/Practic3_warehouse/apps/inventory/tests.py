from django.test import TestCase


class InventorySmokeTest(TestCase):
    def test_project_loads(self):
        self.assertTrue(True)
