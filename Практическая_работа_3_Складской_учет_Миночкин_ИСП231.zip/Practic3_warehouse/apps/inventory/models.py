from django.conf import settings
from django.core.validators import MinValueValidator
from django.db import models

from apps.catalog.models import Product, Supplier, WarehouseLocation


class StockBalance(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="balances", verbose_name="Товар")
    location = models.ForeignKey(
        WarehouseLocation,
        on_delete=models.PROTECT,
        related_name="balances",
        verbose_name="Место хранения",
    )
    quantity = models.DecimalField(
        "Количество",
        max_digits=14,
        decimal_places=3,
        default=0,
        validators=[MinValueValidator(0)],
    )
    updated_at = models.DateTimeField("Обновлено", auto_now=True)

    class Meta:
        verbose_name = "Остаток"
        verbose_name_plural = "Остатки"
        constraints = [
            models.UniqueConstraint(fields=("product", "location"), name="unique_product_location_balance")
        ]

    def __str__(self):
        return f"{self.product} / {self.location}: {self.quantity}"


class Receipt(models.Model):
    class Status(models.TextChoices):
        DRAFT = "draft", "Черновик"
        ACCEPTED = "accepted", "Принято"
        CANCELLED = "cancelled", "Отменено"

    number = models.CharField("Номер приёмки", max_length=64, unique=True)
    supplier = models.ForeignKey(Supplier, on_delete=models.PROTECT, related_name="receipts", verbose_name="Поставщик")
    received_at = models.DateTimeField("Дата приёмки")
    status = models.CharField("Статус", max_length=16, choices=Status.choices, default=Status.DRAFT)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="created_receipts",
        verbose_name="Принял",
    )
    comment = models.TextField("Комментарий", blank=True)

    class Meta:
        verbose_name = "Приёмка"
        verbose_name_plural = "Приёмки"
        ordering = ("-received_at",)

    def __str__(self):
        return self.number


class ReceiptItem(models.Model):
    receipt = models.ForeignKey(Receipt, on_delete=models.CASCADE, related_name="items", verbose_name="Приёмка")
    product = models.ForeignKey(Product, on_delete=models.PROTECT, verbose_name="Товар")
    location = models.ForeignKey(WarehouseLocation, on_delete=models.PROTECT, verbose_name="Размещение")
    quantity = models.DecimalField("Количество", max_digits=14, decimal_places=3, validators=[MinValueValidator(0.001)])

    class Meta:
        verbose_name = "Позиция приёмки"
        verbose_name_plural = "Позиции приёмки"

    def __str__(self):
        return f"{self.receipt.number}: {self.product} × {self.quantity}"


class StockMovement(models.Model):
    product = models.ForeignKey(Product, on_delete=models.PROTECT, related_name="movements", verbose_name="Товар")
    source = models.ForeignKey(
        WarehouseLocation,
        on_delete=models.PROTECT,
        related_name="outgoing_movements",
        verbose_name="Откуда",
    )
    destination = models.ForeignKey(
        WarehouseLocation,
        on_delete=models.PROTECT,
        related_name="incoming_movements",
        verbose_name="Куда",
    )
    quantity = models.DecimalField("Количество", max_digits=14, decimal_places=3, validators=[MinValueValidator(0.001)])
    moved_at = models.DateTimeField("Дата перемещения", auto_now_add=True)
    moved_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, verbose_name="Выполнил")
    comment = models.TextField("Комментарий", blank=True)

    class Meta:
        verbose_name = "Перемещение"
        verbose_name_plural = "Перемещения"
        ordering = ("-moved_at",)

    def __str__(self):
        return f"{self.product}: {self.source} → {self.destination}"


class Shipment(models.Model):
    class Status(models.TextChoices):
        DRAFT = "draft", "Черновик"
        PICKING = "picking", "Комплектуется"
        SHIPPED = "shipped", "Отгружено"
        CANCELLED = "cancelled", "Отменено"

    number = models.CharField("Номер отгрузки", max_length=64, unique=True)
    destination = models.CharField("Получатель / направление", max_length=255)
    planned_at = models.DateTimeField("Плановая дата")
    shipped_at = models.DateTimeField("Фактическая дата", blank=True, null=True)
    status = models.CharField("Статус", max_length=16, choices=Status.choices, default=Status.DRAFT)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, verbose_name="Создал")

    class Meta:
        verbose_name = "Отгрузка"
        verbose_name_plural = "Отгрузки"
        ordering = ("-planned_at",)

    def __str__(self):
        return self.number


class ShipmentItem(models.Model):
    shipment = models.ForeignKey(Shipment, on_delete=models.CASCADE, related_name="items", verbose_name="Отгрузка")
    product = models.ForeignKey(Product, on_delete=models.PROTECT, verbose_name="Товар")
    location = models.ForeignKey(WarehouseLocation, on_delete=models.PROTECT, verbose_name="Место отбора")
    quantity = models.DecimalField("Количество", max_digits=14, decimal_places=3, validators=[MinValueValidator(0.001)])

    class Meta:
        verbose_name = "Позиция отгрузки"
        verbose_name_plural = "Позиции отгрузки"

    def __str__(self):
        return f"{self.shipment.number}: {self.product} × {self.quantity}"


class InventoryCount(models.Model):
    class Status(models.TextChoices):
        OPEN = "open", "Открыта"
        COMPLETED = "completed", "Завершена"

    number = models.CharField("Номер инвентаризации", max_length=64, unique=True)
    started_at = models.DateTimeField("Начало", auto_now_add=True)
    completed_at = models.DateTimeField("Завершение", blank=True, null=True)
    status = models.CharField("Статус", max_length=16, choices=Status.choices, default=Status.OPEN)
    responsible = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, verbose_name="Ответственный")

    class Meta:
        verbose_name = "Инвентаризация"
        verbose_name_plural = "Инвентаризации"
        ordering = ("-started_at",)

    def __str__(self):
        return self.number


class InventoryCountItem(models.Model):
    inventory = models.ForeignKey(InventoryCount, on_delete=models.CASCADE, related_name="items", verbose_name="Инвентаризация")
    product = models.ForeignKey(Product, on_delete=models.PROTECT, verbose_name="Товар")
    location = models.ForeignKey(WarehouseLocation, on_delete=models.PROTECT, verbose_name="Место хранения")
    expected_quantity = models.DecimalField("Учётное количество", max_digits=14, decimal_places=3)
    actual_quantity = models.DecimalField("Фактическое количество", max_digits=14, decimal_places=3)

    class Meta:
        verbose_name = "Позиция инвентаризации"
        verbose_name_plural = "Позиции инвентаризации"

    @property
    def difference(self):
        return self.actual_quantity - self.expected_quantity

    def __str__(self):
        return f"{self.inventory.number}: {self.product}"


class Notification(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="notifications", verbose_name="Получатель")
    title = models.CharField("Заголовок", max_length=255)
    message = models.TextField("Сообщение")
    is_read = models.BooleanField("Прочитано", default=False)
    created_at = models.DateTimeField("Создано", auto_now_add=True)

    class Meta:
        verbose_name = "Уведомление"
        verbose_name_plural = "Уведомления"
        ordering = ("-created_at",)

    def __str__(self):
        return self.title
