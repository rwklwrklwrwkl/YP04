from django.contrib.auth.decorators import login_required
from django.db.models import F, Sum
from django.shortcuts import render

from .models import StockBalance


@login_required
def dashboard(request):
    balances = (
        StockBalance.objects.select_related("product", "location")
        .order_by("product__name", "location__code")
    )
    total_positions = balances.count()
    total_quantity = balances.aggregate(total=Sum("quantity"))["total"] or 0
    low_stock = balances.filter(quantity__lte=F("product__minimum_stock"))

    return render(
        request,
        "inventory/dashboard.html",
        {
            "balances": balances[:100],
            "total_positions": total_positions,
            "total_quantity": total_quantity,
            "low_stock_count": low_stock.count(),
        },
    )
