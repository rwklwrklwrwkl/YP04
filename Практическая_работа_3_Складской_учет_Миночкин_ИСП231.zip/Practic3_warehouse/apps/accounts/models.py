from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    """Пользователь системы складского учёта."""

    class Role(models.TextChoices):
        ADMIN = "admin", "Администратор"
        STOREKEEPER = "storekeeper", "Кладовщик"
        WAREHOUSE_MANAGER = "warehouse_manager", "Менеджер склада"
        SUPPLIER_LOGISTICS = "supplier_logistics", "Поставщик / логист"
        ANALYST = "analyst", "Аналитик"

    full_name = models.CharField("ФИО", max_length=255, blank=True)
    role = models.CharField(
        "Роль",
        max_length=32,
        choices=Role.choices,
        default=Role.STOREKEEPER,
    )

    class Meta:
        verbose_name = "Пользователь"
        verbose_name_plural = "Пользователи"

    def __str__(self):
        return self.full_name or self.username
