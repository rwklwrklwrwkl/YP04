from django.contrib import admin

from .models import Category, Product, Supplier, WarehouseLocation


@admin.register(WarehouseLocation)
class WarehouseLocationAdmin(admin.ModelAdmin):
    list_display = ("code", "name")
    search_fields = ("code", "name")


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("id", "name")
    search_fields = ("name",)


@admin.register(Supplier)
class SupplierAdmin(admin.ModelAdmin):
    list_display = ("name", "contact_person", "phone", "email")
    search_fields = ("name", "contact_person", "phone", "email")


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ("sku", "name", "category", "supplier", "unit", "minimum_stock", "is_active")
    list_filter = ("category", "supplier", "unit", "is_active")
    search_fields = ("sku", "barcode", "name")
    autocomplete_fields = ("category", "supplier")
