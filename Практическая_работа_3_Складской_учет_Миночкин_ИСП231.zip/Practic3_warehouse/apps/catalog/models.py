from django.db import models


class WarehouseLocation(models.Model):
    """Зона, стеллаж, ячейка или другое место хранения."""

    name = models.CharField("Название", max_length=255)
    code = models.CharField("Код", max_length=64, unique=True)
    description = models.TextField("Описание", blank=True)

    class Meta:
        verbose_name = "Место хранения"
        verbose_name_plural = "Места хранения"
        ordering = ("code",)

    def __str__(self):
        return f"{self.code} — {self.name}"


class Category(models.Model):
    name = models.CharField("Название", max_length=255, unique=True)

    class Meta:
        verbose_name = "Категория товара"
        verbose_name_plural = "Категории товаров"
        ordering = ("name",)

    def __str__(self):
        return self.name


class Supplier(models.Model):
    name = models.CharField("Наименование", max_length=255, unique=True)
    contact_person = models.CharField("Контактное лицо", max_length=255, blank=True)
    phone = models.CharField("Телефон", max_length=64, blank=True)
    email = models.EmailField("E-mail", blank=True)

    class Meta:
        verbose_name = "Поставщик"
        verbose_name_plural = "Поставщики"
        ordering = ("name",)

    def __str__(self):
        return self.name


class Product(models.Model):
    class Unit(models.TextChoices):
        PIECE = "pcs", "шт."
        KG = "kg", "кг"
        LITER = "l", "л"
        BOX = "box", "кор."

    sku = models.CharField("Артикул", max_length=64, unique=True)
    barcode = models.CharField("Штрихкод", max_length=64, unique=True, blank=True, null=True)
    name = models.CharField("Наименование", max_length=255)
    category = models.ForeignKey(
        Category,
        on_delete=models.PROTECT,
        related_name="products",
        verbose_name="Категория",
    )
    supplier = models.ForeignKey(
        Supplier,
        on_delete=models.PROTECT,
        related_name="products",
        verbose_name="Основной поставщик",
        blank=True,
        null=True,
    )
    unit = models.CharField("Единица измерения", max_length=16, choices=Unit.choices, default=Unit.PIECE)
    minimum_stock = models.DecimalField("Минимальный остаток", max_digits=12, decimal_places=3, default=0)
    is_active = models.BooleanField("Активен", default=True)

    class Meta:
        verbose_name = "Товар"
        verbose_name_plural = "Товары"
        ordering = ("name",)

    def __str__(self):
        return f"{self.sku} — {self.name}"
