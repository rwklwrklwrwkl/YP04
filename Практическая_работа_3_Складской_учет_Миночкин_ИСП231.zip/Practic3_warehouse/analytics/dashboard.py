"""Простой аналитический дашборд Streamlit для складского учёта."""
import os

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")

import django

django.setup()

import pandas as pd
import streamlit as st

from apps.inventory.models import StockBalance

st.set_page_config(page_title="Аналитика склада", layout="wide")
st.title("Аналитика складских остатков")

rows = list(
    StockBalance.objects.values(
        "product__sku",
        "product__name",
        "location__code",
        "quantity",
        "product__minimum_stock",
    )
)

df = pd.DataFrame(rows)
if df.empty:
    st.info("Данных об остатках пока нет.")
else:
    st.metric("Количество складских позиций", len(df))
    st.metric("Суммарный остаток", float(df["quantity"].sum()))
    df["Ниже минимума"] = df["quantity"] <= df["product__minimum_stock"]
    st.dataframe(df, use_container_width=True)
