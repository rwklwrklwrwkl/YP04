@echo off
chcp 65001 >nul
echo ===================================================
echo Запуск Django сервера WMS (Складской учёт)
echo Адрес: http://127.0.0.1:8000/
echo ===================================================

if exist .venv\Scripts\activate.bat (
    call .venv\Scripts\activate.bat
) else if exist ..\.venv\Scripts\activate.bat (
    call ..\.venv\Scripts\activate.bat
)

python app\manage.py runserver
pause
