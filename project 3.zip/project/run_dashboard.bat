echo ===================================================
echo Запуск аналитического дашборда Streamlit WMS
echo Адрес: http://localhost:8501/
echo ===================================================

if exist .venv\Scripts\activate.bat (
    call .venv\Scripts\activate.bat
) else if exist ..\.venv\Scripts\activate.bat (
    call ..\.venv\Scripts\activate.bat
)

where streamlit >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    streamlit run app\analytics\dashboard.py
) else (
    python -m streamlit run app\analytics\dashboard.py
)
pause
