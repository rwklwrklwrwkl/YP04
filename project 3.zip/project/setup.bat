echo ===================================================
echo Инициализация и настройка WMS (Складской учёт)
echo ===================================================

if exist .venv\Scripts\activate.bat (
    call .venv\Scripts\activate.bat
) else if exist ..\.venv\Scripts\activate.bat (
    call ..\.venv\Scripts\activate.bat
)

echo.
echo [1/2] Применение миграций базы данных Django...
python app\manage.py migrate
if %ERRORLEVEL% NEQ 0 (
    echo Ошибка при применении миграций!
    pause
    exit /b %ERRORLEVEL%
)

echo.
echo [2/2] Наполнение демонстрационными данными...
python app\seed_demo_data.py
if %ERRORLEVEL% NEQ 0 (
    echo Ошибка при заполнении демо-данных!
    pause
    exit /b %ERRORLEVEL%
)

echo.
echo ===================================================
echo Настройка успешно завершена!
echo Для запуска веб-сервера используйте run_server.bat
echo Для запуска дашборда используйте run_dashboard.bat
echo ===================================================
pause
