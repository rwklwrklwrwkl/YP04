from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render


def login_view(request):
    error = None
    if request.user.is_authenticated:
        return redirect("/")
    if request.method == "POST":
        username = request.POST.get("username", "")
        password = request.POST.get("password", "")
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            next_url = request.GET.get("next", "/")
            return redirect(next_url)
        else:
            error = "Неверное имя пользователя или пароль."
    return render(request, "accounts/login.html", {"error": error})


@login_required
def logout_view(request):
    if request.method == "POST":
        logout(request)
    return redirect("accounts:login")
