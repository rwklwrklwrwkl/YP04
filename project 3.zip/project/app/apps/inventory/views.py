from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.db.models import F, Sum
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from .forms import ReceiptForm, ReceiptItemFormSet, ShipmentForm, ShipmentItemFormSet, StockMovementForm
from .models import (
    InventoryCount,
    Notification,
    Receipt,
    Shipment,
    StockBalance,
    StockMovement,
)


# ---------------------------------------------------------------------------
# Вспомогательные функции
# ---------------------------------------------------------------------------

def check_low_stock(user):
    """Создаёт уведомления для товаров с остатком ниже минимального."""
    low = StockBalance.objects.filter(
        quantity__lte=F("product__minimum_stock")
    ).select_related("product", "location")
    for balance in low:
        already = Notification.objects.filter(
            user=user,
            title__icontains=balance.product.sku,
            is_read=False,
        ).exists()
        if not already:
            Notification.objects.create(
                user=user,
                title=f"Низкий остаток: {balance.product.sku}",
                message=(
                    f"Товар «{balance.product.name}» в локации «{balance.location}» "
                    f"имеет остаток {balance.quantity} {balance.product.get_unit_display()}, "
                    f"что не превышает минимального уровня {balance.product.minimum_stock}."
                ),
            )


# ---------------------------------------------------------------------------
# Дашборд
# ---------------------------------------------------------------------------

@login_required
def dashboard(request):
    balances = (
        StockBalance.objects.select_related("product", "location")
        .order_by("product__name", "location__code")
    )
    total_positions = balances.count()
    total_quantity = balances.aggregate(total=Sum("quantity"))["total"] or 0
    low_stock = balances.filter(quantity__lte=F("product__minimum_stock"))
    recent_receipts = Receipt.objects.select_related("supplier").order_by("-received_at")[:5]
    recent_shipments = Shipment.objects.order_by("-planned_at")[:5]

    return render(
        request,
        "inventory/dashboard.html",
        {
            "balances": balances[:100],
            "total_positions": total_positions,
            "total_quantity": total_quantity,
            "low_stock_count": low_stock.count(),
            "recent_receipts": recent_receipts,
            "recent_shipments": recent_shipments,
        },
    )


# ---------------------------------------------------------------------------
# Приёмки
# ---------------------------------------------------------------------------

@login_required
def receipt_list(request):
    receipts = Receipt.objects.select_related("supplier", "created_by").order_by("-received_at")
    return render(request, "inventory/receipt_list.html", {"receipts": receipts})


@login_required
def receipt_create(request):
    if request.method == "POST":
        form = ReceiptForm(request.POST)
        formset = ReceiptItemFormSet(request.POST)
        if form.is_valid() and formset.is_valid():
            with transaction.atomic():
                receipt = form.save(commit=False)
                receipt.created_by = request.user
                receipt.save()
                formset.instance = receipt
                formset.save()
            messages.success(request, f"Приёмка «{receipt.number}» создана.")
            return redirect("inventory:receipt_list")
    else:
        form = ReceiptForm()
        formset = ReceiptItemFormSet()
    return render(request, "inventory/receipt_form.html", {"form": form, "formset": formset})


@login_required
def receipt_accept(request, pk):
    receipt = get_object_or_404(Receipt, pk=pk)
    if request.method != "POST":
        return redirect("inventory:receipt_list")
    if receipt.status != Receipt.Status.DRAFT:
        messages.error(request, "Приёмка уже проведена или отменена.")
        return redirect("inventory:receipt_list")
    with transaction.atomic():
        for item in receipt.items.select_related("product", "location").all():
            balance, _ = StockBalance.objects.get_or_create(
                product=item.product,
                location=item.location,
                defaults={"quantity": 0},
            )
            balance.quantity += item.quantity
            balance.save()
        receipt.status = Receipt.Status.ACCEPTED
        receipt.save()
        Notification.objects.create(
            user=request.user,
            title=f"Приёмка {receipt.number} проведена",
            message=f"Приёмка от поставщика «{receipt.supplier}» успешно проведена.",
        )
    check_low_stock(request.user)
    messages.success(request, f"Приёмка «{receipt.number}» проведена.")
    return redirect("inventory:receipt_list")


# ---------------------------------------------------------------------------
# Отгрузки
# ---------------------------------------------------------------------------

@login_required
def shipment_list(request):
    shipments = Shipment.objects.select_related("created_by").order_by("-planned_at")
    return render(request, "inventory/shipment_list.html", {"shipments": shipments})


@login_required
def shipment_create(request):
    if request.method == "POST":
        form = ShipmentForm(request.POST)
        formset = ShipmentItemFormSet(request.POST)
        if form.is_valid() and formset.is_valid():
            with transaction.atomic():
                shipment = form.save(commit=False)
                shipment.created_by = request.user
                shipment.save()
                formset.instance = shipment
                formset.save()
            messages.success(request, f"Отгрузка «{shipment.number}» создана.")
            return redirect("inventory:shipment_list")
    else:
        form = ShipmentForm()
        formset = ShipmentItemFormSet()
    return render(request, "inventory/shipment_form.html", {"form": form, "formset": formset})


@login_required
def shipment_ship(request, pk):
    shipment = get_object_or_404(Shipment, pk=pk)
    if request.method != "POST":
        return redirect("inventory:shipment_list")
    if shipment.status == Shipment.Status.SHIPPED:
        messages.error(request, "Отгрузка уже выполнена.")
        return redirect("inventory:shipment_list")
    items = shipment.items.select_related("product", "location").all()
    with transaction.atomic():
        for item in items:
            try:
                balance = StockBalance.objects.select_for_update().get(
                    product=item.product, location=item.location
                )
            except StockBalance.DoesNotExist:
                messages.error(
                    request,
                    f"Нет остатка для товара «{item.product}» в локации «{item.location}».",
                )
                return redirect("inventory:shipment_list")
            if balance.quantity < item.quantity:
                messages.error(
                    request,
                    f"Недостаточно товара «{item.product}» в «{item.location}»: "
                    f"доступно {balance.quantity}, требуется {item.quantity}.",
                )
                return redirect("inventory:shipment_list")
        for item in items:
            balance = StockBalance.objects.select_for_update().get(
                product=item.product, location=item.location
            )
            balance.quantity -= item.quantity
            balance.save()
        shipment.status = Shipment.Status.SHIPPED
        shipment.shipped_at = timezone.now()
        shipment.save()
        Notification.objects.create(
            user=request.user,
            title=f"Отгрузка {shipment.number} выполнена",
            message=f"Отгрузка в «{shipment.destination}» успешно проведена.",
        )
    check_low_stock(request.user)
    messages.success(request, f"Отгрузка «{shipment.number}» выполнена.")
    return redirect("inventory:shipment_list")


# ---------------------------------------------------------------------------
# Перемещения
# ---------------------------------------------------------------------------

@login_required
def movement_list(request):
    movements = StockMovement.objects.select_related(
        "product", "source", "destination", "moved_by"
    ).order_by("-moved_at")
    return render(request, "inventory/movement_list.html", {"movements": movements})


@login_required
def movement_create(request):
    if request.method == "POST":
        form = StockMovementForm(request.POST)
        if form.is_valid():
            product = form.cleaned_data["product"]
            source = form.cleaned_data["source"]
            destination = form.cleaned_data["destination"]
            quantity = form.cleaned_data["quantity"]
            with transaction.atomic():
                try:
                    src_balance = StockBalance.objects.select_for_update().get(
                        product=product, location=source
                    )
                except StockBalance.DoesNotExist:
                    messages.error(request, f"Нет остатка товара «{product}» в локации «{source}».")
                    return render(request, "inventory/movement_form.html", {"form": form})
                if src_balance.quantity < quantity:
                    messages.error(
                        request,
                        f"Недостаточно товара «{product}» в «{source}»: "
                        f"доступно {src_balance.quantity}, требуется {quantity}.",
                    )
                    return render(request, "inventory/movement_form.html", {"form": form})
                src_balance.quantity -= quantity
                src_balance.save()
                dst_balance, _ = StockBalance.objects.get_or_create(
                    product=product,
                    location=destination,
                    defaults={"quantity": 0},
                )
                dst_balance.quantity += quantity
                dst_balance.save()
                movement = form.save(commit=False)
                movement.moved_by = request.user
                movement.save()
            messages.success(request, "Перемещение выполнено.")
            return redirect("inventory:movement_list")
    else:
        form = StockMovementForm()
    return render(request, "inventory/movement_form.html", {"form": form})


# ---------------------------------------------------------------------------
# Инвентаризации
# ---------------------------------------------------------------------------

@login_required
def inventory_list(request):
    inventories = InventoryCount.objects.select_related("responsible").order_by("-started_at")
    return render(request, "inventory/inventory_list.html", {"inventories": inventories})


# ---------------------------------------------------------------------------
# Уведомления
# ---------------------------------------------------------------------------

@login_required
def notification_list(request):
    if request.method == "POST":
        notif_id = request.POST.get("mark_read")
        if notif_id:
            Notification.objects.filter(pk=notif_id, user=request.user).update(is_read=True)
        return redirect("inventory:notification_list")

    notifications = request.user.notifications.order_by("is_read", "-created_at")
    return render(request, "inventory/notification_list.html", {"notifications": notifications})
