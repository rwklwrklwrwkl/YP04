import django.core.validators
import django.db.models.deletion
import django.utils.timezone
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ("accounts", "0001_initial"),
        ("catalog", "0001_initial"),
    ]

    operations = [
        migrations.CreateModel(
            name="StockBalance",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("quantity", models.DecimalField(
                    decimal_places=3,
                    default=0,
                    max_digits=14,
                    validators=[django.core.validators.MinValueValidator(0)],
                    verbose_name="Количество",
                )),
                ("updated_at", models.DateTimeField(auto_now=True, verbose_name="Обновлено")),
                ("product", models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name="balances",
                    to="catalog.product",
                    verbose_name="Товар",
                )),
                ("location", models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    related_name="balances",
                    to="catalog.warehouselocation",
                    verbose_name="Место хранения",
                )),
            ],
            options={
                "verbose_name": "Остаток",
                "verbose_name_plural": "Остатки",
            },
        ),
        migrations.AddConstraint(
            model_name="stockbalance",
            constraint=models.UniqueConstraint(fields=("product", "location"), name="unique_product_location_balance"),
        ),
        migrations.CreateModel(
            name="Receipt",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("number", models.CharField(max_length=64, unique=True, verbose_name="Номер приёмки")),
                ("received_at", models.DateTimeField(verbose_name="Дата приёмки")),
                ("status", models.CharField(
                    choices=[("draft", "Черновик"), ("accepted", "Принято"), ("cancelled", "Отменено")],
                    default="draft",
                    max_length=16,
                    verbose_name="Статус",
                )),
                ("comment", models.TextField(blank=True, verbose_name="Комментарий")),
                ("supplier", models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    related_name="receipts",
                    to="catalog.supplier",
                    verbose_name="Поставщик",
                )),
                ("created_by", models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    related_name="created_receipts",
                    to=settings.AUTH_USER_MODEL,
                    verbose_name="Принял",
                )),
            ],
            options={
                "verbose_name": "Приёмка",
                "verbose_name_plural": "Приёмки",
                "ordering": ("-received_at",),
            },
        ),
        migrations.CreateModel(
            name="ReceiptItem",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("quantity", models.DecimalField(
                    decimal_places=3,
                    max_digits=14,
                    validators=[django.core.validators.MinValueValidator(0.001)],
                    verbose_name="Количество",
                )),
                ("receipt", models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name="items",
                    to="inventory.receipt",
                    verbose_name="Приёмка",
                )),
                ("product", models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    to="catalog.product",
                    verbose_name="Товар",
                )),
                ("location", models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    to="catalog.warehouselocation",
                    verbose_name="Размещение",
                )),
            ],
            options={
                "verbose_name": "Позиция приёмки",
                "verbose_name_plural": "Позиции приёмки",
            },
        ),
        migrations.CreateModel(
            name="Shipment",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("number", models.CharField(max_length=64, unique=True, verbose_name="Номер отгрузки")),
                ("destination", models.CharField(max_length=255, verbose_name="Получатель / направление")),
                ("planned_at", models.DateTimeField(verbose_name="Плановая дата")),
                ("shipped_at", models.DateTimeField(blank=True, null=True, verbose_name="Фактическая дата")),
                ("status", models.CharField(
                    choices=[
                        ("draft", "Черновик"),
                        ("picking", "Комплектуется"),
                        ("shipped", "Отгружено"),
                        ("cancelled", "Отменено"),
                    ],
                    default="draft",
                    max_length=16,
                    verbose_name="Статус",
                )),
                ("created_by", models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    to=settings.AUTH_USER_MODEL,
                    verbose_name="Создал",
                )),
            ],
            options={
                "verbose_name": "Отгрузка",
                "verbose_name_plural": "Отгрузки",
                "ordering": ("-planned_at",),
            },
        ),
        migrations.CreateModel(
            name="ShipmentItem",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("quantity", models.DecimalField(
                    decimal_places=3,
                    max_digits=14,
                    validators=[django.core.validators.MinValueValidator(0.001)],
                    verbose_name="Количество",
                )),
                ("shipment", models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name="items",
                    to="inventory.shipment",
                    verbose_name="Отгрузка",
                )),
                ("product", models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    to="catalog.product",
                    verbose_name="Товар",
                )),
                ("location", models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    to="catalog.warehouselocation",
                    verbose_name="Место отбора",
                )),
            ],
            options={
                "verbose_name": "Позиция отгрузки",
                "verbose_name_plural": "Позиции отгрузки",
            },
        ),
        migrations.CreateModel(
            name="StockMovement",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("quantity", models.DecimalField(
                    decimal_places=3,
                    max_digits=14,
                    validators=[django.core.validators.MinValueValidator(0.001)],
                    verbose_name="Количество",
                )),
                ("moved_at", models.DateTimeField(auto_now_add=True, verbose_name="Дата перемещения")),
                ("comment", models.TextField(blank=True, verbose_name="Комментарий")),
                ("product", models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    related_name="movements",
                    to="catalog.product",
                    verbose_name="Товар",
                )),
                ("source", models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    related_name="outgoing_movements",
                    to="catalog.warehouselocation",
                    verbose_name="Откуда",
                )),
                ("destination", models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    related_name="incoming_movements",
                    to="catalog.warehouselocation",
                    verbose_name="Куда",
                )),
                ("moved_by", models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    to=settings.AUTH_USER_MODEL,
                    verbose_name="Выполнил",
                )),
            ],
            options={
                "verbose_name": "Перемещение",
                "verbose_name_plural": "Перемещения",
                "ordering": ("-moved_at",),
            },
        ),
        migrations.CreateModel(
            name="InventoryCount",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("number", models.CharField(max_length=64, unique=True, verbose_name="Номер инвентаризации")),
                ("started_at", models.DateTimeField(auto_now_add=True, verbose_name="Начало")),
                ("completed_at", models.DateTimeField(blank=True, null=True, verbose_name="Завершение")),
                ("status", models.CharField(
                    choices=[("open", "Открыта"), ("completed", "Завершена")],
                    default="open",
                    max_length=16,
                    verbose_name="Статус",
                )),
                ("responsible", models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    to=settings.AUTH_USER_MODEL,
                    verbose_name="Ответственный",
                )),
            ],
            options={
                "verbose_name": "Инвентаризация",
                "verbose_name_plural": "Инвентаризации",
                "ordering": ("-started_at",),
            },
        ),
        migrations.CreateModel(
            name="InventoryCountItem",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("expected_quantity", models.DecimalField(decimal_places=3, max_digits=14, verbose_name="Учётное количество")),
                ("actual_quantity", models.DecimalField(decimal_places=3, max_digits=14, verbose_name="Фактическое количество")),
                ("inventory", models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name="items",
                    to="inventory.inventorycount",
                    verbose_name="Инвентаризация",
                )),
                ("product", models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    to="catalog.product",
                    verbose_name="Товар",
                )),
                ("location", models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    to="catalog.warehouselocation",
                    verbose_name="Место хранения",
                )),
            ],
            options={
                "verbose_name": "Позиция инвентаризации",
                "verbose_name_plural": "Позиции инвентаризации",
            },
        ),
        migrations.CreateModel(
            name="Notification",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("title", models.CharField(max_length=255, verbose_name="Заголовок")),
                ("message", models.TextField(verbose_name="Сообщение")),
                ("is_read", models.BooleanField(default=False, verbose_name="Прочитано")),
                ("created_at", models.DateTimeField(auto_now_add=True, verbose_name="Создано")),
                ("user", models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name="notifications",
                    to=settings.AUTH_USER_MODEL,
                    verbose_name="Получатель",
                )),
            ],
            options={
                "verbose_name": "Уведомление",
                "verbose_name_plural": "Уведомления",
                "ordering": ("-created_at",),
            },
        ),
    ]
