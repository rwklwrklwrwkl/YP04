from django import forms
from django.forms import inlineformset_factory

from .models import Receipt, ReceiptItem, Shipment, ShipmentItem, StockMovement


class ReceiptForm(forms.ModelForm):
    class Meta:
        model = Receipt
        fields = ["number", "supplier", "received_at", "comment"]
        widgets = {
            "received_at": forms.DateTimeInput(attrs={"type": "datetime-local"}, format="%Y-%m-%dT%H:%M"),
            "comment": forms.Textarea(attrs={"rows": 3}),
        }
        labels = {
            "number": "Номер приёмки",
            "supplier": "Поставщик",
            "received_at": "Дата приёмки",
            "comment": "Комментарий",
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["received_at"].input_formats = ["%Y-%m-%dT%H:%M"]


class ReceiptItemForm(forms.ModelForm):
    class Meta:
        model = ReceiptItem
        fields = ["product", "location", "quantity"]
        labels = {
            "product": "Товар",
            "location": "Место размещения",
            "quantity": "Количество",
        }


ReceiptItemFormSet = inlineformset_factory(
    Receipt,
    ReceiptItem,
    form=ReceiptItemForm,
    extra=1,
    can_delete=True,
)


class ShipmentForm(forms.ModelForm):
    class Meta:
        model = Shipment
        fields = ["number", "destination", "planned_at"]
        widgets = {
            "planned_at": forms.DateTimeInput(attrs={"type": "datetime-local"}, format="%Y-%m-%dT%H:%M"),
        }
        labels = {
            "number": "Номер отгрузки",
            "destination": "Получатель / направление",
            "planned_at": "Плановая дата",
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["planned_at"].input_formats = ["%Y-%m-%dT%H:%M"]


class ShipmentItemForm(forms.ModelForm):
    class Meta:
        model = ShipmentItem
        fields = ["product", "location", "quantity"]
        labels = {
            "product": "Товар",
            "location": "Место отбора",
            "quantity": "Количество",
        }


ShipmentItemFormSet = inlineformset_factory(
    Shipment,
    ShipmentItem,
    form=ShipmentItemForm,
    extra=1,
    can_delete=True,
)


class StockMovementForm(forms.ModelForm):
    class Meta:
        model = StockMovement
        fields = ["product", "source", "destination", "quantity", "comment"]
        widgets = {
            "comment": forms.Textarea(attrs={"rows": 3}),
        }
        labels = {
            "product": "Товар",
            "source": "Откуда",
            "destination": "Куда",
            "quantity": "Количество",
            "comment": "Комментарий",
        }
