from django.urls import path

from . import views

app_name = "inventory"

urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    # Приёмки
    path("receipts/", views.receipt_list, name="receipt_list"),
    path("receipts/create/", views.receipt_create, name="receipt_create"),
    path("receipts/<int:pk>/accept/", views.receipt_accept, name="receipt_accept"),
    # Отгрузки
    path("shipments/", views.shipment_list, name="shipment_list"),
    path("shipments/create/", views.shipment_create, name="shipment_create"),
    path("shipments/<int:pk>/ship/", views.shipment_ship, name="shipment_ship"),
    # Перемещения
    path("movements/", views.movement_list, name="movement_list"),
    path("movements/create/", views.movement_create, name="movement_create"),
    # Инвентаризации
    path("inventory/", views.inventory_list, name="inventory_list"),
    # Уведомления
    path("notifications/", views.notification_list, name="notification_list"),
]
