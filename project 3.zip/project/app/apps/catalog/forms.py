from django import forms


class ProductSearchForm(forms.Form):
    query = forms.CharField(
        label="Поиск",
        required=False,
        widget=forms.TextInput(attrs={"placeholder": "Артикул или наименование...", "class": "form-control"}),
    )
