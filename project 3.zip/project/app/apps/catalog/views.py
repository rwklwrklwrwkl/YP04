from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, render

from apps.catalog.forms import ProductSearchForm
from apps.catalog.models import Product
from apps.inventory.models import StockBalance


@login_required
def product_list(request):
    form = ProductSearchForm(request.GET or None)
    products = Product.objects.select_related("category", "supplier").filter(is_active=True)
    if form.is_valid():
        q = form.cleaned_data.get("query", "").strip()
        if q:
            products = products.filter(name__icontains=q) | products.filter(sku__icontains=q)
    return render(request, "catalog/product_list.html", {"form": form, "products": products})


@login_required
def product_detail(request, pk):
    product = get_object_or_404(Product, pk=pk)
    balances = StockBalance.objects.filter(product=product).select_related("location")
    return render(request, "catalog/product_detail.html", {"product": product, "balances": balances})
