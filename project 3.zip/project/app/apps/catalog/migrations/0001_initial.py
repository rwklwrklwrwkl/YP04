from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name="Category",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=255, unique=True, verbose_name="Название")),
            ],
            options={
                "verbose_name": "Категория товара",
                "verbose_name_plural": "Категории товаров",
                "ordering": ("name",),
            },
        ),
        migrations.CreateModel(
            name="Supplier",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=255, unique=True, verbose_name="Наименование")),
                ("contact_person", models.CharField(blank=True, max_length=255, verbose_name="Контактное лицо")),
                ("phone", models.CharField(blank=True, max_length=64, verbose_name="Телефон")),
                ("email", models.EmailField(blank=True, verbose_name="E-mail")),
            ],
            options={
                "verbose_name": "Поставщик",
                "verbose_name_plural": "Поставщики",
                "ordering": ("name",),
            },
        ),
        migrations.CreateModel(
            name="WarehouseLocation",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=255, verbose_name="Название")),
                ("code", models.CharField(max_length=64, unique=True, verbose_name="Код")),
                ("description", models.TextField(blank=True, verbose_name="Описание")),
            ],
            options={
                "verbose_name": "Место хранения",
                "verbose_name_plural": "Места хранения",
                "ordering": ("code",),
            },
        ),
        migrations.CreateModel(
            name="Product",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("sku", models.CharField(max_length=64, unique=True, verbose_name="Артикул")),
                ("barcode", models.CharField(blank=True, max_length=64, null=True, unique=True, verbose_name="Штрихкод")),
                ("name", models.CharField(max_length=255, verbose_name="Наименование")),
                ("unit", models.CharField(
                    choices=[("pcs", "шт."), ("kg", "кг"), ("l", "л"), ("box", "кор.")],
                    default="pcs",
                    max_length=16,
                    verbose_name="Единица измерения",
                )),
                ("minimum_stock", models.DecimalField(decimal_places=3, default=0, max_digits=12, verbose_name="Минимальный остаток")),
                ("is_active", models.BooleanField(default=True, verbose_name="Активен")),
                ("category", models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    related_name="products",
                    to="catalog.category",
                    verbose_name="Категория",
                )),
                ("supplier", models.ForeignKey(
                    blank=True,
                    null=True,
                    on_delete=django.db.models.deletion.PROTECT,
                    related_name="products",
                    to="catalog.supplier",
                    verbose_name="Основной поставщик",
                )),
            ],
            options={
                "verbose_name": "Товар",
                "verbose_name_plural": "Товары",
                "ordering": ("name",),
            },
        ),
    ]
