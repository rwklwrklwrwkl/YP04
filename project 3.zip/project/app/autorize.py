# -*- coding: utf-8 -*-
"""Автономный десктопный модуль авторизации кладовщика (Tkinter + SHA-256)."""

import hashlib
import tkinter as tk
from tkinter import messagebox

# Хэширование пароля
def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()

# Демонстрационная локальная база пользователей
USERS = {
    "admin": hash_password("admin123"),
    "storekeeper": hash_password("password123"),
    "manager": hash_password("password123"),
    "user": hash_password("qwerty"),
}

MAX_ATTEMPTS = 3
attempts_left = MAX_ATTEMPTS


def toggle_password_visibility():
    """Показывает / скрывает пароль по клику на чекбокс."""
    if show_password_var.get():
        entry_password.config(show="")
    else:
        entry_password.config(show="*")


def check_login(event=None):
    """Проверяет введённые логин и пароль."""
    global attempts_left

    login = entry_login.get().strip()
    password = entry_password.get()

    if not login or not password:
        messagebox.showwarning("Внимание", "Заполните все поля!")
        return

    password_hash = hash_password(password)

    if login in USERS and USERS[login] == password_hash:
        messagebox.showinfo("Успех", f"Добро пожаловать в WMS, {login}!")
        attempts_left = MAX_ATTEMPTS
    else:
        attempts_left -= 1
        if attempts_left > 0:
            messagebox.showerror(
                "Ошибка",
                f"Неверный логин или пароль.\nОсталось попыток: {attempts_left}",
            )
        else:
            messagebox.showerror(
                "Блокировка",
                "Превышено число попыток. Приложение будет закрыто.",
            )
            root.destroy()
            return

    entry_password.delete(0, tk.END)
    entry_password.focus()


# Создание окна
root = tk.Tk()
root.title("WMS — Авторизация кладовщика")
root.geometry("380x360")
root.resizable(False, False)
root.configure(bg="#f4f6f8")

label_title = tk.Label(
    root,
    text="Вход в систему WMS",
    font=("Arial", 16, "bold"),
    bg="#f4f6f8",
    fg="#1e293b",
)
label_title.pack(pady=15)

label_login = tk.Label(root, text="Логин:", font=("Arial", 10), bg="#f4f6f8", anchor="w")
label_login.pack(fill="x", padx=40, pady=(5, 0))

entry_login = tk.Entry(root, font=("Arial", 11), width=30)
entry_login.pack(padx=40, pady=5)
entry_login.focus()

label_password = tk.Label(root, text="Пароль:", font=("Arial", 10), bg="#f4f6f8", anchor="w")
label_password.pack(fill="x", padx=40, pady=(10, 0))

entry_password = tk.Entry(root, font=("Arial", 11), width=30, show="*")
entry_password.pack(padx=40, pady=5)

show_password_var = tk.BooleanVar(value=False)
check_show = tk.Checkbutton(
    root,
    text="Показать пароль",
    variable=show_password_var,
    command=toggle_password_visibility,
    bg="#f4f6f8",
    activebackground="#f4f6f8",
    font=("Arial", 9),
)
check_show.pack(anchor="w", padx=40, pady=5)

btn_login = tk.Button(
    root,
    text="Войти в систему",
    command=check_login,
    bg="#2563eb",
    fg="white",
    activebackground="#1d4ed8",
    activeforeground="white",
    font=("Arial", 11, "bold"),
    cursor="hand2",
    width=20,
    pady=6,
    relief="flat",
)
btn_login.pack(pady=20)

root.bind("<Return>", check_login)

if __name__ == "__main__":
    root.mainloop()
