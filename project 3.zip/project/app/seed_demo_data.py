"""Скрипт первичного наполнения демонстрационными данными WMS (складской учёт).

Запуск:
    python app/seed_demo_data.py
    или из каталога app:
    python seed_demo_data.py
"""

import os
import sys
from decimal import Decimal
from pathlib import Path

# Добавляем каталог app в sys.path
CURRENT_DIR = Path(__file__).resolve().parent
if str(CURRENT_DIR) not in sys.path:
    sys.path.insert(0, str(CURRENT_DIR))

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")

import django

django.setup()

from django.contrib.auth import get_user_model
from django.utils import timezone
from apps.catalog.models import Category, Product, Supplier, WarehouseLocation
from apps.inventory.models import (
    InventoryCount,
    InventoryCountItem,
    Notification,
    Receipt,
    ReceiptItem,
    Shipment,
    ShipmentItem,
    StockBalance,
    StockMovement,
)

User = get_user_model()


def seed_data():
    print("Начало наполнения базы данных демонстрационными данными...")

    # -------------------------------------------------------------------------
    # 1. Пользователи с ролевой моделью
    # -------------------------------------------------------------------------
    print("1. Создание пользователей...")
    users_data = [
        {
            "username": "admin",
            "full_name": "Администратор Системы",
            "role": User.Role.ADMIN,
            "email": "admin@warehouse.local",
            "is_staff": True,
            "is_superuser": True,
        },
        {
            "username": "storekeeper",
            "full_name": "Иванов Иван Иванович",
            "role": User.Role.STOREKEEPER,
            "email": "ivanov@warehouse.local",
            "is_staff": False,
            "is_superuser": False,
        },
        {
            "username": "manager",
            "full_name": "Петрова Анна Сергеевна",
            "role": User.Role.WAREHOUSE_MANAGER,
            "email": "petrova@warehouse.local",
            "is_staff": True,
            "is_superuser": False,
        },
        {
            "username": "logistics",
            "full_name": "Сидоров Алексей Михайлович",
            "role": User.Role.SUPPLIER_LOGISTICS,
            "email": "sidorov@warehouse.local",
            "is_staff": False,
            "is_superuser": False,
        },
        {
            "username": "analyst",
            "full_name": "Смирнов Дмитрий Павлович",
            "role": User.Role.ANALYST,
            "email": "smirnov@warehouse.local",
            "is_staff": False,
            "is_superuser": False,
        },
    ]

    users = {}
    for udata in users_data:
        username = udata["username"]
        user, created = User.objects.get_or_create(
            username=username,
            defaults={
                "full_name": udata["full_name"],
                "role": udata["role"],
                "email": udata["email"],
                "is_staff": udata["is_staff"],
                "is_superuser": udata["is_superuser"],
            },
        )
        user.set_password("admin123" if username == "admin" else "password123")
        user.role = udata["role"]
        user.full_name = udata["full_name"]
        user.save()
        users[username] = user
        status = "создан" if created else "обновлен"
        print(f"   Пользователь: {username} ({user.get_role_display()}) - {status}")

    # -------------------------------------------------------------------------
    # 2. Места хранения (локации)
    # -------------------------------------------------------------------------
    print("2. Создание мест хранения...")
    locations_data = [
        {"code": "A-01-01", "name": "Стеллаж A1, ячейка 1", "description": "Зона штучного отбора (легкие грузы)"},
        {"code": "A-01-02", "name": "Стеллаж A1, ячейка 2", "description": "Зона штучного отбора (инструмент)"},
        {"code": "A-02-01", "name": "Стеллаж A2, ячейка 1", "description": "Зона мелкоштучного крепежа"},
        {"code": "B-01-01", "name": "Стеллаж B1, поддон 1", "description": "Нижний ярус, тяжелые сыпучие материалы"},
        {"code": "B-02-01", "name": "Стеллаж B2, консоль 1", "description": "Длинномерные материалы и трубы"},
        {"code": "REC-01", "name": "Зона входного контроля", "description": "Буфер приёмки товаров от поставщиков"},
        {"code": "EXP-01", "name": "Зона экспедиции и отгрузки", "description": "Зона готовых к отправке заказов"},
    ]

    locations = {}
    for loc in locations_data:
        obj, created = WarehouseLocation.objects.get_or_create(
            code=loc["code"],
            defaults={"name": loc["name"], "description": loc["description"]},
        )
        locations[loc["code"]] = obj
        print(f"   Локация: {obj.code} ({obj.name})")

    # -------------------------------------------------------------------------
    # 3. Категории товаров
    # -------------------------------------------------------------------------
    print("3. Создание категорий...")
    categories_names = [
        "Электроинструмент и оборудование",
        "Крепёж и метизы",
        "Строительные смеси и химия",
        "Сантехническое оборудование",
        "Спецодежда и СИЗ",
    ]
    categories = {}
    for cat_name in categories_names:
        cat_obj, _ = Category.objects.get_or_create(name=cat_name)
        categories[cat_name] = cat_obj
        print(f"   Категория: {cat_obj.name}")

    # -------------------------------------------------------------------------
    # 4. Поставщики
    # -------------------------------------------------------------------------
    print("4. Создание поставщиков...")
    suppliers_data = [
        {
            "name": "ООО «ТехноПромСнаб»",
            "contact_person": "Васильев Олег Петрович",
            "phone": "+7 (495) 123-45-67",
            "email": "order@technopromsnab.ru",
        },
        {
            "name": "АО «МетизКомплект»",
            "contact_person": "Кузнецова Елена Викторовна",
            "phone": "+7 (812) 987-65-43",
            "email": "sales@metizkomplekt.ru",
        },
        {
            "name": "ТД «СтройБаза №1»",
            "contact_person": "Григорьев Роман Николаевич",
            "phone": "+7 (495) 555-77-88",
            "email": "postavka@stroybaza1.ru",
        },
        {
            "name": "ООО «СантехРесурс»",
            "contact_person": "Михайлов Денис Андреевич",
            "phone": "+7 (495) 333-22-11",
            "email": "opt@santehresurs.ru",
        },
    ]

    suppliers = {}
    for sup in suppliers_data:
        sup_obj, _ = Supplier.objects.get_or_create(
            name=sup["name"],
            defaults={
                "contact_person": sup["contact_person"],
                "phone": sup["phone"],
                "email": sup["email"],
            },
        )
        suppliers[sup["name"]] = sup_obj
        print(f"   Поставщик: {sup_obj.name}")

    # -------------------------------------------------------------------------
    # 5. Номенклатура товаров
    # -------------------------------------------------------------------------
    print("5. Создание товаров...")
    products_data = [
        {
            "sku": "PRD-00101",
            "barcode": "4059955342011",
            "name": "Перфоратор сетевой Bosch GBH 2-26 DRE",
            "category": categories["Электроинструмент и оборудование"],
            "supplier": suppliers["ООО «ТехноПромСнаб»"],
            "unit": Product.Unit.PIECE,
            "minimum_stock": Decimal("5.000"),
        },
        {
            "sku": "PRD-00102",
            "barcode": "0088381096959",
            "name": "Угловая шлифмашина Makita 9558HN (125 мм)",
            "category": categories["Электроинструмент и оборудование"],
            "supplier": suppliers["ООО «ТехноПромСнаб»"],
            "unit": Product.Unit.PIECE,
            "minimum_stock": Decimal("8.000"),
        },
        {
            "sku": "PRD-00201",
            "barcode": "4607012340012",
            "name": "Саморезы по металлу 3.5х25 мм (фасовка 1000 шт)",
            "category": categories["Крепёж и метизы"],
            "supplier": suppliers["АО «МетизКомплект»"],
            "unit": Product.Unit.BOX,
            "minimum_stock": Decimal("20.000"),
        },
        {
            "sku": "PRD-00202",
            "barcode": "4607012340029",
            "name": "Анкерный болт с гайкой 10х100 мм (50 шт)",
            "category": categories["Крепёж и метизы"],
            "supplier": suppliers["АО «МетизКомплект»"],
            "unit": Product.Unit.BOX,
            "minimum_stock": Decimal("15.000"),
        },
        {
            "sku": "PRD-00301",
            "barcode": "4606112001054",
            "name": "Штукатурка гипсовая Knauf Ротбанд (мешок 30 кг)",
            "category": categories["Строительные смеси и химия"],
            "supplier": suppliers["ТД «СтройБаза №1»"],
            "unit": Product.Unit.KG,
            "minimum_stock": Decimal("500.000"),
        },
        {
            "sku": "PRD-00302",
            "barcode": "4600123456789",
            "name": "Грунтовка глубокого проникновения Ceresit CT 17 (10 л)",
            "category": categories["Строительные смеси и химия"],
            "supplier": suppliers["ТД «СтройБаза №1»"],
            "unit": Product.Unit.LITER,
            "minimum_stock": Decimal("30.000"),
        },
        {
            "sku": "PRD-00401",
            "barcode": "4603332221110",
            "name": "Кран шаровый латунный полнопроходной Valtec 1/2\"",
            "category": categories["Сантехническое оборудование"],
            "supplier": suppliers["ООО «СантехРесурс»"],
            "unit": Product.Unit.PIECE,
            "minimum_stock": Decimal("25.000"),
        },
        {
            "sku": "PRD-00402",
            "barcode": "4603332221127",
            "name": "Труба полипропиленовая армированная стекловолокном 25мм (4м)",
            "category": categories["Сантехническое оборудование"],
            "supplier": suppliers["ООО «СантехРесурс»"],
            "unit": Product.Unit.PIECE,
            "minimum_stock": Decimal("40.000"),
        },
        {
            "sku": "PRD-00501",
            "barcode": "4609998887771",
            "name": "Перчатки защитные х/б с двойным нитриловым обливом",
            "category": categories["Спецодежда и СИЗ"],
            "supplier": suppliers["ООО «ТехноПромСнаб»"],
            "unit": Product.Unit.PIECE,
            "minimum_stock": Decimal("100.000"),
        },
        {
            "sku": "PRD-00502",
            "barcode": "4609998887788",
            "name": "Каска защитная ударопрочная СОМЗ-55 Фаворит (оранжевая)",
            "category": categories["Спецодежда и СИЗ"],
            "supplier": suppliers["ООО «ТехноПромСнаб»"],
            "unit": Product.Unit.PIECE,
            "minimum_stock": Decimal("15.000"),
        },
    ]

    products = {}
    for pdata in products_data:
        p_obj, _ = Product.objects.get_or_create(
            sku=pdata["sku"],
            defaults={
                "barcode": pdata["barcode"],
                "name": pdata["name"],
                "category": pdata["category"],
                "supplier": pdata["supplier"],
                "unit": pdata["unit"],
                "minimum_stock": pdata["minimum_stock"],
                "is_active": True,
            },
        )
        products[pdata["sku"]] = p_obj
        print(f"   Товар: [{p_obj.sku}] {p_obj.name}")

    # -------------------------------------------------------------------------
    # 6. Остатки на складе (StockBalance)
    # -------------------------------------------------------------------------
    print("6. Наполнение складских остатков...")
    balances_data = [
        {"sku": "PRD-00101", "location": "A-01-01", "qty": Decimal("18.000")},
        {"sku": "PRD-00102", "location": "A-01-02", "qty": Decimal("6.000")},   # Внимание: < min 8.000 (демонстрация предупреждения)
        {"sku": "PRD-00201", "location": "A-02-01", "qty": Decimal("45.000")},
        {"sku": "PRD-00202", "location": "A-02-01", "qty": Decimal("12.000")},  # Внимание: < min 15.000
        {"sku": "PRD-00301", "location": "B-01-01", "qty": Decimal("1200.000")},
        {"sku": "PRD-00302", "location": "B-01-01", "qty": Decimal("50.000")},
        {"sku": "PRD-00401", "location": "A-01-01", "qty": Decimal("85.000")},
        {"sku": "PRD-00402", "location": "B-02-01", "qty": Decimal("65.000")},
        {"sku": "PRD-00501", "location": "A-01-02", "qty": Decimal("240.000")},
        {"sku": "PRD-00502", "location": "A-01-02", "qty": Decimal("22.000")},
    ]

    for bdata in balances_data:
        bal, _ = StockBalance.objects.update_or_create(
            product=products[bdata["sku"]],
            location=locations[bdata["location"]],
            defaults={"quantity": bdata["qty"]},
        )
        print(f"   Остаток: {bal.product.sku} в {bal.location.code} = {bal.quantity}")

    # -------------------------------------------------------------------------
    # 7. Демонстрационная приёмка (Receipt)
    # -------------------------------------------------------------------------
    print("7. Создание приёмок...")
    now = timezone.now()

    # Приёмка 1: Проведённая
    receipt1, _ = Receipt.objects.get_or_create(
        number="REC-2026-0001",
        defaults={
            "supplier": suppliers["ООО «ТехноПромСнаб»"],
            "received_at": now - timezone.timedelta(days=4, hours=3),
            "status": Receipt.Status.ACCEPTED,
            "created_by": users["storekeeper"],
            "comment": "Плановое поступление электроинструмента по договору №45-П.",
        },
    )
    ReceiptItem.objects.get_or_create(
        receipt=receipt1,
        product=products["PRD-00101"],
        location=locations["A-01-01"],
        defaults={"quantity": Decimal("10.000")},
    )
    ReceiptItem.objects.get_or_create(
        receipt=receipt1,
        product=products["PRD-00102"],
        location=locations["A-01-02"],
        defaults={"quantity": Decimal("6.000")},
    )
    print(f"   Приёмка: {receipt1.number} (Статус: {receipt1.get_status_display()})")

    # Приёмка 2: Черновик
    receipt2, _ = Receipt.objects.get_or_create(
        number="REC-2026-0002",
        defaults={
            "supplier": suppliers["ТД «СтройБаза №1»"],
            "received_at": now - timezone.timedelta(hours=5),
            "status": Receipt.Status.DRAFT,
            "created_by": users["storekeeper"],
            "comment": "Поставка сухих смесей. Разгрузка в зоне входного контроля.",
        },
    )
    ReceiptItem.objects.get_or_create(
        receipt=receipt2,
        product=products["PRD-00301"],
        location=locations["REC-01"],
        defaults={"quantity": Decimal("300.000")},
    )
    print(f"   Приёмка: {receipt2.number} (Статус: {receipt2.get_status_display()})")

    # -------------------------------------------------------------------------
    # 8. Демонстрационная отгрузка (Shipment)
    # -------------------------------------------------------------------------
    print("8. Создание отгрузок...")

    # Отгрузка 1: Выполненная
    shipment1, _ = Shipment.objects.get_or_create(
        number="SHP-2026-0001",
        defaults={
            "destination": "ООО «СтройГрупп Девелопмент» (Строительный объект Север)",
            "planned_at": now - timezone.timedelta(days=2),
            "shipped_at": now - timezone.timedelta(days=2, hours=1),
            "status": Shipment.Status.SHIPPED,
            "created_by": users["manager"],
        },
    )
    ShipmentItem.objects.get_or_create(
        shipment=shipment1,
        product=products["PRD-00101"],
        location=locations["A-01-01"],
        defaults={"quantity": Decimal("2.000")},
    )
    ShipmentItem.objects.get_or_create(
        shipment=shipment1,
        product=products["PRD-00301"],
        location=locations["B-01-01"],
        defaults={"quantity": Decimal("150.000")},
    )
    print(f"   Отгрузка: {shipment1.number} (Статус: {shipment1.get_status_display()})")

    # Отгрузка 2: В процессе комплектования
    shipment2, _ = Shipment.objects.get_or_create(
        number="SHP-2026-0002",
        defaults={
            "destination": "ИП Смирнов К.В. (Ремонтно-монтажный участок №3)",
            "planned_at": now + timezone.timedelta(days=1),
            "shipped_at": None,
            "status": Shipment.Status.PICKING,
            "created_by": users["manager"],
        },
    )
    ShipmentItem.objects.get_or_create(
        shipment=shipment2,
        product=products["PRD-00401"],
        location=locations["A-01-01"],
        defaults={"quantity": Decimal("10.000")},
    )
    ShipmentItem.objects.get_or_create(
        shipment=shipment2,
        product=products["PRD-00201"],
        location=locations["A-02-01"],
        defaults={"quantity": Decimal("5.000")},
    )
    print(f"   Отгрузка: {shipment2.number} (Статус: {shipment2.get_status_display()})")

    # -------------------------------------------------------------------------
    # 9. Внутрискладские перемещения (StockMovement)
    # -------------------------------------------------------------------------
    print("9. Создание записей перемещений...")
    StockMovement.objects.get_or_create(
        product=products["PRD-00101"],
        source=locations["REC-01"],
        destination=locations["A-01-01"],
        quantity=Decimal("10.000"),
        defaults={
            "moved_by": users["storekeeper"],
            "comment": "Перемещение партии электроинструмента из буфера приёмки в ячейку постоянного хранения.",
        },
    )

    # -------------------------------------------------------------------------
    # 10. Инвентаризация (InventoryCount)
    # -------------------------------------------------------------------------
    print("10. Создание инвентаризации...")
    inv1, _ = InventoryCount.objects.get_or_create(
        number="INV-2026-001",
        defaults={
            "responsible": users["manager"],
            "status": InventoryCount.Status.COMPLETED,
            "started_at": now - timezone.timedelta(days=10),
            "completed_at": now - timezone.timedelta(days=9, hours=20),
        },
    )
    InventoryCountItem.objects.get_or_create(
        inventory=inv1,
        product=products["PRD-00101"],
        location=locations["A-01-01"],
        defaults={
            "expected_quantity": Decimal("18.000"),
            "actual_quantity": Decimal("18.000"),
        },
    )
    InventoryCountItem.objects.get_or_create(
        inventory=inv1,
        product=products["PRD-00201"],
        location=locations["A-02-01"],
        defaults={
            "expected_quantity": Decimal("45.000"),
            "actual_quantity": Decimal("45.000"),
        },
    )
    print(f"   Инвентаризация: {inv1.number} (Статус: {inv1.get_status_display()})")

    # -------------------------------------------------------------------------
    # 11. Системные уведомления (Notification)
    # -------------------------------------------------------------------------
    print("11. Создание уведомлений...")
    Notification.objects.get_or_create(
        user=users["manager"],
        title="Низкий остаток: PRD-00102",
        defaults={
            "message": (
                "Товар «Угловая шлифмашина Makita 9558HN (125 мм)» в локации «A-01-02 — Стеллаж A1, ячейка 2» "
                "имеет текущий остаток 6.000 шт., что ниже установленного минимума 8.000 шт. "
                "Рекомендуется сформировать заказ поставщику."
            ),
            "is_read": False,
        },
    )
    Notification.objects.get_or_create(
        user=users["storekeeper"],
        title="Приёмка REC-2026-0001 проведена",
        defaults={
            "message": "Приёмка от поставщика «ООО «ТехноПромСнаб»» успешно проведена, остатки обновлены.",
            "is_read": True,
        },
    )

    print("---")
    print("Демонстрационные данные успешно заполнены!")
    print(f"Итого товаров: {Product.objects.count()}")
    print(f"Итого мест хранения: {WarehouseLocation.objects.count()}")
    print(f"Итого остатков: {StockBalance.objects.count()}")
    print(f"Итого приёмок: {Receipt.objects.count()}")
    print(f"Итого отгрузок: {Shipment.objects.count()}")


if __name__ == "__main__":
    seed_data()
