"""Аналитический дашборд Streamlit для складского учёта."""
import os
import sys

# Добавляем корень проекта в PYTHONPATH
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")

import django

django.setup()

import pandas as pd
import streamlit as st
from django.utils import timezone

from apps.inventory.models import Receipt, Shipment, StockBalance, StockMovement

st.set_page_config(page_title="Аналитика склада", layout="wide")
st.title("📊 Аналитика складских остатков")

# ---------------------------------------------------------------------------
# Данные об остатках
# ---------------------------------------------------------------------------
rows = list(
    StockBalance.objects.values(
        "product__sku",
        "product__name",
        "location__code",
        "quantity",
        "product__minimum_stock",
    )
)
df = pd.DataFrame(rows)
if not df.empty:
    df["quantity"] = pd.to_numeric(df["quantity"], errors="coerce").fillna(0.0)
    df["product__minimum_stock"] = pd.to_numeric(df["product__minimum_stock"], errors="coerce").fillna(0.0)

now = timezone.now()
thirty_days_ago = now - timezone.timedelta(days=30)

receipts_count = Receipt.objects.filter(received_at__gte=thirty_days_ago).count()
shipments_count = Shipment.objects.filter(planned_at__gte=thirty_days_ago).count()

# ---------------------------------------------------------------------------
# Метрики
# ---------------------------------------------------------------------------
col1, col2, col3, col4 = st.columns(4)
with col1:
    st.metric("Складских позиций", len(df) if not df.empty else 0)
with col2:
    st.metric("Суммарный остаток", float(df["quantity"].sum()) if not df.empty else 0)
with col3:
    st.metric("Приёмок за 30 дней", receipts_count)
with col4:
    st.metric("Отгрузок за 30 дней", shipments_count)

st.divider()

if df.empty:
    st.info("Данных об остатках пока нет.")
else:
    df["Ниже минимума"] = df["quantity"] <= df["product__minimum_stock"]

    # ---------------------------------------------------------------------------
    # Топ-10 товаров по остатку
    # ---------------------------------------------------------------------------
    st.subheader("🏆 Топ-10 товаров по суммарному остатку")
    top10 = (
        df.groupby("product__name")["quantity"]
        .sum()
        .nlargest(10)
        .reset_index()
        .rename(columns={"product__name": "Товар", "quantity": "Остаток"})
    )
    st.bar_chart(top10.set_index("Товар"))

    # ---------------------------------------------------------------------------
    # Товары ниже минимального остатка
    # ---------------------------------------------------------------------------
    low_df = df[df["Ниже минимума"]].copy()
    low_df = low_df.rename(columns={
        "product__sku": "Артикул",
        "product__name": "Наименование",
        "location__code": "Локация",
        "quantity": "Остаток",
        "product__minimum_stock": "Минимум",
    })
    st.subheader(f"⚠️ Товары ниже минимального остатка ({len(low_df)})")
    if low_df.empty:
        st.success("Всё в норме — нет товаров ниже минимального остатка.")
    else:
        st.dataframe(low_df[["Артикул", "Наименование", "Локация", "Остаток", "Минимум"]], use_container_width=True)

    # ---------------------------------------------------------------------------
    # Все остатки
    # ---------------------------------------------------------------------------
    st.subheader("📦 Все складские остатки")
    st.dataframe(
        df.rename(columns={
            "product__sku": "Артикул",
            "product__name": "Наименование",
            "location__code": "Локация",
            "quantity": "Количество",
            "product__minimum_stock": "Минимальный остаток",
        }),
        use_container_width=True,
    )

# ---------------------------------------------------------------------------
# Последние 10 перемещений
# ---------------------------------------------------------------------------
st.subheader("🔄 Последние 10 перемещений")
movements = list(
    StockMovement.objects.select_related("product", "source", "destination", "moved_by")
    .order_by("-moved_at")[:10]
    .values(
        "product__sku",
        "product__name",
        "source__code",
        "destination__code",
        "quantity",
        "moved_at",
        "moved_by__username",
    )
)
if movements:
    mdf = pd.DataFrame(movements)
    mdf["quantity"] = pd.to_numeric(mdf["quantity"], errors="coerce").fillna(0.0)
    mdf = mdf.rename(columns={
        "product__sku": "Артикул",
        "product__name": "Товар",
        "source__code": "Откуда",
        "destination__code": "Куда",
        "quantity": "Количество",
        "moved_at": "Дата",
        "moved_by__username": "Выполнил",
    })
    st.dataframe(mdf, use_container_width=True)
else:
    st.info("Перемещений пока нет.")
